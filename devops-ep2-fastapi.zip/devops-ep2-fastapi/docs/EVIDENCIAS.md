# Evidencias y Reflexiones (EP2)

## Evidencias
- Capturas de ejecución de pipelines (Actions).
- Capturas de Dependabot PRs.
- Reportes (capturas) de Snyk en el job `security`.
- Salida de `curl` a `/health` en despliegue con Compose.

## Reflexiones individuales
> Estas reflexiones deben ser originales y sin uso de IA.

**Integrante A**  
- ¿Qué aprendí del diseño del pipeline?  
- ¿Cómo integré pruebas y seguridad?  
- ¿Qué desafíos tuve y cómo los resolví?

**Integrante B**  
- ¿Qué aprendí del despliegue y la orquestación?  
- ¿Cómo validé trazabilidad y gobernanza?  
- ¿Qué mejoraría a futuro?
